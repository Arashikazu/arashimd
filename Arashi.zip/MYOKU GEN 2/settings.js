/*
   Created By ArxzyDev
   My Contact wa.me/6289513081052
*/

const fs = require('fs')
const chalk = require('chalk')

/* ~~~~~~~~~ WEB API ~~~~~~~~~ */
global.lol = '' // https://api.lolhuman.xyz
global.xzn = '' // https://xnz.wtf
/* ~~~~~~~~~ SETTINGS OWNER ~~~~~~~~~ */
global.numberowner = '6285173054788' // Owner Utama
global.owner = ['6285173054788'] // Owner Lainnya
global.namaowner = 'Abi' // Nama Owner
global.premium = ["6285173054788"] // Premium User
global.nobot = '6283155895835'
/* ~~~~~~~~~ SETTINGS BOT ~~~~~~~~~ */
global.namabot = 'ARASHI-MD' // NickBot
global.typemenu = 'v2' // 'v1' > 'v2' > 'v3' > 'v4'
global.typereply = 'v1' // 'v1' > 'v2'
global.autoread = false // ReadChat
global.autobio = false // AutoBio
global.autoblok212 = true // AutoBlock Nomer +212
global.onlyindo = true  // AutoBlock Selain Nomer Indo
global.packname = 'Created By ARASHI-MD' // Watermark Sticker
global.author = 'ARASHI-MD' // Watermark Sticker
/* ~~~~~~~~~ MESSAGES ~~~~~~~~~ */
global.mess = {
    done: 'Selesai!',
    prem: 'Fitur ini hanya tersedia untuk pengguna _*PREMIUM*_',
    admin: 'Fitur ini hanya tersedia untuk _*ADMIN GROUP*_',
    botAdmin: 'Fitur ini hanya bisa digunakan jika bot menjadi _*ADMIN GROUP*_',
    owner: 'Fitur ini hanya tersedia untuk _*OWNER*_',
    group: 'Fitur ini hanya tersedia di _*GROUP*_',
    private: 'Fitur ini hanya tersedia di _*PRIVATE CHAT*_',
    wait: 'Tunggu sebentar, sedang memproses',    
    error: 'Maaf, fitur ini sedang error',
}
/* ~~~~~~~~~ THUMBNAIL ~~~~~~~~~ */
global.thumb = fs.readFileSync('./media/quoted.jpg')
global.menu = fs.readFileSync('./media/menu.jpg')
/* ~~~~~~~~~ EDITS LINK ~~~~~~~~~ */
global.link = 'https://chat.whatsapp.com/BZz2aytLQRC5SgwFlnql0k'
/* ~~~~~~~~~ END SYSTEM ~~~~~~~~~ */
let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`Update'${__filename}'`))
    delete require.cache[file]
    require(file)
})
